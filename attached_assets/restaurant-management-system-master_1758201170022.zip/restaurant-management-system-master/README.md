GKMIT Restaurant :- Restaurant to order and find delicious food.

Restaurant Website using MERN Stack.

Technology Used:-
1.ReactJS(Frontend)
2.Advance CSS
3.NodeJS(Backend)
4.Vercel
5.Heroku

Home Page:-

![Screenshot 2022-11-12 at 3 52 38 PM](https://user-images.githubusercontent.com/114575434/215434030-bdbdbb0a-3825-4a63-891f-017d0e79cb58.png)


Food Page:-


![Screenshot 2022-11-12 at 3 52 56 PM](https://user-images.githubusercontent.com/114575434/215434166-7c62e6ed-0cbe-4cba-bb24-9f7d898f7035.png)


Cart Page:-
![Screenshot 2022-11-12 at 3 53 23 PM](https://user-images.githubusercontent.com/114575434/215434212-0c1cfffa-0693-4e1b-a5b0-d76e758e25b7.png)


Contact Us Page:-
![Screenshot 2022-11-12 at 3 53 37 PM](https://user-images.githubusercontent.com/114575434/215434312-96e29da1-8491-4f27-8853-f87bc7f2d713.png)



Free Live Demo:-https://restaurant-frontend-5teja4ug1-himanshur25.vercel.app/
